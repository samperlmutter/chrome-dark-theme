# Chrome Dark Theme

A dark theme for Chrome. Forked from the popular [Material Incognito Dark Theme](https://github.com/Fiddle-N/material-incognito-dark-theme/).
